"""Reforzamiento 07"""


"""7. Crear un diccionario con 6 departamentos en el país.
➢ Borrar cualquier departamento (uno) usando la palabra reservada del.
➢ Comprobar que no existe este departamento borrado dentro del diccionario."""

"""Diccionario"""

departamentos = {"Ceviche": "Lima", "Picante de Cuy": "Ancash", "Rocoto Relleno": "Arequipa", "Carapulcra": "Ica", "Pachamanca": "Huanuco", "Puca Picante": "Ayacucho"}

del departamentos["Ceviche"]

print(departamentos)
