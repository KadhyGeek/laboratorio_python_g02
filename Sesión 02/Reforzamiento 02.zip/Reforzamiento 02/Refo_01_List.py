"""Reforzamiento 01"""


"""1. Crear una lista de 6 objetos y mostrar en pantalla (ítems de cursos que lleves o hayas
llevado en la universidad)"""

"""Variables"""

var1 = ["Base de datos", "Algoritmos", "python", "Redes", "Android", "Java"]

print("Los elementos de la lista var1 som: {}".format(var1))