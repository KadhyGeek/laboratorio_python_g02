"""Reforzamiento 11"""


"""11. Crear una lista (entre floats y booleanos, 6 elementos mínimo) donde imprimas el
penúltimo y último valor (por índice)."""

"""Listas"""

lista = [1.2, 2.5, True, 5.2, False, 10.8]

print("El primer y penúltimo elemento de la lista es {} y {} respectivamente".format(lista[0],lista[len(lista) - 2]))


