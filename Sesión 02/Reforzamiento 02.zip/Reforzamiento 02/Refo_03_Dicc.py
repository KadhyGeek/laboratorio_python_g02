"""Reforzamiento 03"""


"""3. Agrega un nuevo key llamado “dni” con su respectivo valor y luego mostrar el valor
desalario en consola.

var[‘key’] = tuValor"""

"""Diccionario"""

empleado = {"nombre": "Margaret", "edad": 27, "salario": 2800}

empleado["dni"] = 24369837

print("El salario del empleado es: {}".format(empleado["salario"]))