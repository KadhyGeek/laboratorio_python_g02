"""Reforzamiento 13"""


"""13. Elimina ahora todoslos elementos de la lista creada previamente y mostrar en consola
el estado de la lista."""

"""Variables"""

lista = [1.2, 2, True, "PHP", 10.8, 8<2]

lista.clear()

print("el estado de la lista es: {}".format(lista))
