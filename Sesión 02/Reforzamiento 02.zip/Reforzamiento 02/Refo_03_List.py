"""Reforzamiento 03"""


"""3. Quitar 2 elementos de tu nueva lista de ítems por valor, no por índice."""

"""Variables"""

var1= ["MySQL", "Algoritmos", "Python", "Redes", "Android", "Java", "Oracle", "SQLServer", "SAP", "PHP", "Auditoría", "Modelamiento"]

var1.remove("Algoritmos")
var1.remove("Redes")

print("Los elementos de la lista var1 som: {}".format(var1))

