"""Reforzamiento 09"""


"""9. Sumar las dos listas creadas anteriormente y mostrar el resultado en consola."""

"""Variables"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "PHP", "Java", "Oracle", "SQLServer", "SAP", "Auditoría", "Modelamiento"]

random = [34.2, 50, "Perú", 26, 22.56, "Suecia", 2, 12.6, "Francia"]

suma = cursos + random

print("La lista actualizada es: {} ".format(suma))