"""Reforzamiento 15"""


"""15. Crear una lista con los 100 primeros números enteros."""

"""Listas"""

lista = []

for i in range(100):
    lista.append(i+1)

print(lista)