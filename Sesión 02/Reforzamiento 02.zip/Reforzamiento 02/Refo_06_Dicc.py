"""Reforzamiento 06"""


"""6. Crea un diccionario con los mismos valores sin apuntar a una variable.

dict([(‘key1’, valor1)])"""

"""Diccionario"""

diccionario = dict([("nombre", "Margaret"), ("salario", 2800), ("dni", 24369837)])

print("Mi diccionario es el siguiente: {}".format(diccionario))

