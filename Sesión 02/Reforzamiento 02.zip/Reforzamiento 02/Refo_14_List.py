"""Reforzamiento 14"""


"""14. Elimina un elemento por dos índices existentes y ya no por el valor."""

"""Listas"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "PHP", "Java", "Oracle", "SQLServer", "SAP", "Auditoría", "Modelamiento"]

print(f"La lista es: {cursos}")

del cursos[5]

del cursos[7]

print(f"La lista actualizada es: {cursos}")