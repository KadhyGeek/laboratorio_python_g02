"""Reforzamiento 12"""


"""12. Reconocer los tipos de cada dato en la lista creada y mostrarlas en consola (type())"""

"""Listas"""

lista = [1.2, 2, True, "PHP", 10.8, 8<2]

#print(lista)

for i in lista:
    print("Elemento de lista {} y su tipo: ".format(i),type(i))