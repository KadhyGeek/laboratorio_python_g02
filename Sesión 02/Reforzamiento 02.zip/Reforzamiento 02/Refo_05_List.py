"""Reforzamiento 05"""


"""5. Obtén la cantidad total ítems que tienes en tu lista creada y mostrar el resultado en
consola."""

"""Variables"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "Java", "Oracle", "SQLServer", "SAP", "PHP", "Auditoría", "Modelamiento"]

cant_items=len(cursos)

print("La cantidad de ítems en cursos es: {} ".format(cant_items))