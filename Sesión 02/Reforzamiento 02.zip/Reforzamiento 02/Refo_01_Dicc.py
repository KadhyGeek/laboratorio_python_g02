"""Reforzamiento 01"""


"""11. Crea correctamente un diccionario con los campos de: nombre, edad, salario y edad para un
empleado (tomar en cuenta que cada key tendrá un valor respectivamente)"""

"""Diccionario"""

empleado = {"nombre": "Margaret", "edad": 27, "salario": 2800}

print("Nuestro primer diccionario tiene el siguiente contenido: {}".format(empleado))