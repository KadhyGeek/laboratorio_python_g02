"""Reforzamiento 02"""


"""2. Agregar 6 Objetos o valores nuevos a tu lista anterior, utilizando el método visto en clase."""

"""Variables"""

var1 = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "Java"]

var1.append("Oracle")
var1.append("SQLServer")
var1.append("SAP")
var1.append("POO")
var1.append("Auditoria")
var1.append("Modelamiento")

print("Los elementos de la lista var1 som: {}".format(var1))

