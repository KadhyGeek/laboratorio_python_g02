"""Reforzamiento 07"""


"""7. Borra el primer ítem de la lista mediante su índice."""

"""Variables"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android" ,"PHP", "Java", "Oracle", "SQLServer", "SAP", "Auditoría", "Modelamiento"]

cursos.pop(0)

print("La lista actualizada es: {}".format(cursos))