"""Reforzamiento 08"""


"""8. Crea una nueva lista vacía y agregue ítems (diferentes tipos de datos de manera
desordenada: 3 floats, 3 ints y 3 strings) (append)."""

"""Variables"""

paises=[]

paises.append(34.2)
paises.append(50)
paises.append("Perú")
paises.append(26)
paises.append(22.56)
paises.append("Suecia")
paises.append(2)
paises.append(12.6)
paises.append("Francia")

print("Mi lista actualizada es la siguiente: {}".format(paises))



