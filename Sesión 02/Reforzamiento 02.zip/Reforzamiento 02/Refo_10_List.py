"""Reforzamiento 10"""


"""10. Crea una lista donde luego se pueda usar el método para ordenar elementos (los
elementos tienen que estar desordenados previamente)."""

"""Listas"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "PHP", "Java", "Oracle", "SQLServer", "SAP", "Auditoría", "Modelamiento"]

cursos.sort()

print("La lista ordenada es la siguiente: {}".format(cursos))