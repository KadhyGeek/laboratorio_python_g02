"""Reforzamiento 16"""


"""16. Mostrar sólo los datos comprendidos entre la posición 10 y 35"""

"""Listas"""

lista = []

for i in range(100):
    lista.append(i+1)

print("La lista con los datos de la posición 10 y 35 son: {}".format(lista[10:35]))

