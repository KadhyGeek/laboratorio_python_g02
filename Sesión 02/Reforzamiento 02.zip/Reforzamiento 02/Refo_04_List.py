"""Reforzamiento 04"""


"""4. Invierte y muestra en consola tu lista de cursos."""

"""Variables"""

cursos = ["MySQL", "Algoritmos", "Python", "Redes", "Android", "Java", "Oracle", "SQLServer", "SAP", "PHP", "Auditoría", "Modelamiento"]

cursos.reverse()

print("Los elementos de la lista cursos de forma invertida som: {}".format(cursos))