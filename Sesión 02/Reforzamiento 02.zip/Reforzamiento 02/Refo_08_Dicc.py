"""Reforzamiento 08"""


"""8. Ingresar el nombre de tu carrera dentro de los valores que tienes en tu diccionario ya creado.
➢ Mostrar en consola los valores de su variable final (ya sea diccionario o lista)."""

"""Diccionario"""

datos = {"Ceviche": "Lima", "Picante de Cuy": "Ancash", "Rocoto Relleno": "Arequipa", "Carapulcra": "Ica", "Pachamanca": "Huanuco", "Puca Picante": "Ayacucho"}

datos["Python"]="Ingenieria de Sistemas"

print("El nuevo diccionario actualizado es : {}".format(datos))

