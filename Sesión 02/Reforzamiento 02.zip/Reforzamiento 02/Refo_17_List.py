"""Reforzamiento 17"""


"""17. Crear una lista con los 10 primeros números al cuadrado y mostrar el resultado en
terminal."""

"""Listas"""

lista=[]

for i in range(10):
    lista.append(pow(i+1,2))
print("Loa 10 primeros elementos de la lista son: {}".format(lista))

